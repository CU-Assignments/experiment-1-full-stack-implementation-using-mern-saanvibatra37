document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    // Add login functionality
    console.log('Login submitted');
});

document.getElementById('signupForm').addEventListener('submit', function(e) {
    e.preventDefault();
    // Add signup functionality
    console.log('Signup submitted');
});
